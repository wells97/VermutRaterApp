﻿namespace VermutRaterApp.Services
{
    public interface INotificationManagerService
    {
        Task ShowVermutReminder(); 
    }

}

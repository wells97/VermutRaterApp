namespace VermutRaterApp.Models
{
    public static class Usuario
    {

        public static string Email { get; set; }
        public static string UID { get; set; }

        public static string [] whitelist {get;set;}

    }
}
